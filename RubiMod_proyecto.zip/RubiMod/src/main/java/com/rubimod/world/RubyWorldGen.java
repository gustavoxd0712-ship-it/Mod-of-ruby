package com.rubimod.world;

import com.rubimod.init.ModBlocks;
import java.util.Random;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.chunk.IChunkProvider;
import net.minecraft.world.gen.IChunkGenerator;
import net.minecraft.world.gen.feature.WorldGenMinable;
import net.minecraftforge.fml.common.IWorldGenerator;

/** Genera vetas de rubi en el Overworld (rara, como los diamantes). */
public class RubyWorldGen implements IWorldGenerator {

    // Ajusta estos valores para cambiar la rareza
    private static final int TRIES_PER_CHUNK = 2;
    private static final int VEIN_SIZE = 4;
    private static final int MIN_Y = 5;
    private static final int MAX_Y = 24;

    @Override
    public void generate(Random random, int chunkX, int chunkZ, World world,
                         IChunkGenerator chunkGenerator, IChunkProvider chunkProvider) {
        if (world.provider.getDimension() != 0) {
            return;
        }
        WorldGenMinable vein = new WorldGenMinable(ModBlocks.RUBY_ORE.getDefaultState(), VEIN_SIZE);
        for (int i = 0; i < TRIES_PER_CHUNK; i++) {
            int x = chunkX * 16 + random.nextInt(16);
            int y = MIN_Y + random.nextInt(MAX_Y - MIN_Y + 1);
            int z = chunkZ * 16 + random.nextInt(16);
            vein.generate(world, random, new BlockPos(x, y, z));
        }
    }
}
