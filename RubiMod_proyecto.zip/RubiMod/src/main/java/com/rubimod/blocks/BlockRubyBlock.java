package com.rubimod.blocks;

import com.rubimod.RubiMod;
import net.minecraft.block.Block;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;

public class BlockRubyBlock extends Block {

    public BlockRubyBlock() {
        super(Material.IRON, MapColor.RED);
        setRegistryName(RubiMod.MODID, "ruby_block");
        setUnlocalizedName(RubiMod.MODID + ".ruby_block");
        setCreativeTab(RubiMod.TAB);
        setSoundType(SoundType.METAL);
        setHardness(5.0F);
        setResistance(10.0F);
        setHarvestLevel("pickaxe", 2); // pico de hierro o superior
    }

    @Override
    public boolean isBeaconBase(IBlockAccess world, BlockPos pos, BlockPos beacon) {
        return true;
    }
}
