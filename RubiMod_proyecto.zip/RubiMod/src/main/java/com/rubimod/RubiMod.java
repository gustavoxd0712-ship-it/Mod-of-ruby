package com.rubimod;

import com.rubimod.init.ModBlocks;
import com.rubimod.init.ModItems;
import com.rubimod.world.RubyWorldGen;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraftforge.oredict.OreDictionary;

@Mod(modid = RubiMod.MODID, name = RubiMod.NAME, version = RubiMod.VERSION, acceptedMinecraftVersions = "[1.12.2]")
public class RubiMod {
    public static final String MODID = "rubimod";
    public static final String NAME = "Rubi Mod";
    public static final String VERSION = "1.0.0";

    public static final CreativeTabs TAB = new CreativeTabs(MODID) {
        @Override
        @SideOnly(Side.CLIENT)
        public ItemStack getTabIconItem() {
            return new ItemStack(ModItems.RUBY);
        }
    };

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        GameRegistry.registerWorldGenerator(new RubyWorldGen(), 0);
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        OreDictionary.registerOre("gemRuby", ModItems.RUBY);
        OreDictionary.registerOre("oreRuby", ModBlocks.RUBY_ORE);
        OreDictionary.registerOre("blockRuby", ModBlocks.RUBY_BLOCK);
    }
}
