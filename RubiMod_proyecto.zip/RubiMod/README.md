# Rubi Mod (Forge 1.12.2)

Añade **mena de rubí**, **rubí** y **bloque de rubí**.
- La mena solo se puede picar con pico de **diamante** o mejor.
- Aparece en el Overworld entre las alturas Y 5 y 24 (rareza ajustable en `RubyWorldGen.java`).
- Fortuna y Toque de seda funcionan. Da 3-7 de experiencia.
- Recetas: 9 rubíes = 1 bloque; 1 bloque = 9 rubíes.

## Compilar
**Con PC:** instala Java 8 y Gradle 4.9 (o copia `gradlew`, `gradlew.bat` y la carpeta `gradle/`
del MDK de Forge 1.12.2) y ejecuta:

    gradle setupDecompWorkspace
    gradle build

El .jar queda en `build/libs/`.

**Con GitHub (sin instalar nada):** sube esta carpeta a un repositorio nuevo. En la pestaña
**Actions** se ejecuta "Build mod" y al terminar descargas el .jar desde *Artifacts*.

Para regenerar las texturas: `python3 tools/gen_textures.py` (necesita Pillow).
